Make to compile

raytracer scene1.txt <outputfilename>
raytracer scene2.txt <outputfilename>
raytracer scene3.txt <outputfilename>
raytracer scene4.txt <outputfilename>
raytracer scene5.txt <outputfilename>