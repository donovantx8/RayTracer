#ifndef MatrixTranslate_H
#define MatrixTranslate_H
#include "Matrix.h"

class MatrixTranslate: public Matrix {
	public:
		MatrixTranslate(double x, double y, double z);

};	

#endif // MatrixTranslate_H