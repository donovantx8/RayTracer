#ifndef MatrixScale_H
#define MatrixScale_H
#include "Matrix.h"


class MatrixScale: public Matrix {
	public:
		MatrixScale(double x, double y, double z);

};	

#endif // MatrixScale_H