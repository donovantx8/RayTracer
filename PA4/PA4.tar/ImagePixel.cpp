#include "ImagePixel.h"
#include "Matrix.h"
#include <stdlib.h>
#include <math.h>
#include <vector> 
#define F2B(f) ((f) >= 1.0 ? 255 : (int)((f)*256.0))

ImagePixel::ImagePixel() {
	
}


ImagePixel::ImagePixel(Camera cam, int x, int y){

	Matrix blank;
	double px = (double) x / (cam.wdh -1) * (cam.rgt-cam.lft) + cam.lft;
	double py = (double) y / (cam.hgt -1) * (cam.top-cam.bot) + cam.bot;

	pixpt = cam.FP + ((-cam.focalLength) * cam.WV) + (px * cam.UV) + (-py * cam.VV);

	
}

void ImagePixel::colorPixel(std::vector<Light> sources, Camera cam, Material mat) {
	std::vector<Light>::iterator light_itr;
	std::vector<double> color;
	color.push_back(cam.ambient.at(0) * mat.ka.at(0));
	color.push_back(cam.ambient.at(1) * mat.ka.at(1));
	color.push_back(cam.ambient.at(2) * mat.ka.at(2));
	for (light_itr = sources.begin(); light_itr != sources.end(); light_itr++) {
			
			std::vector<double> ptL = (*light_itr).p;
			std::vector<double> emL = (*light_itr).e;

			std::vector<double> toL = ptL - ections;
			toL = toL % Matrix::vectorLength(toL);
			std::vector<double> snrm;
		
			if (isSphere) {
				snrm = model.Model::calculateSurfaceNormal(ections, center);
			} else {
				snrm = model.Model::calculateSurfaceNormal(face);
			}
			double sndottol = snrm & toL;
	//		Matrix::printVector(snrm);
			if ((sndottol) > 0) {				
			
				/*if (X==29 && Y ==48) {
					Matrix::printVector(color);
					Matrix::printVector(snrm);
					Matrix::printVector(cam.ambient);
					cout << sndottol << endl;
					Matrix::printVector(rayD);
					Matrix::printVector(rayL);
					
				}	*/	
		//		Matrix::printVector(ections);
			//	printf("['%f', '%f', '%f']\n",ections.at(0),ections.at(1),ections.at(2));
				color.at(0) = color.at(0) + (mat.kd.at(0) * emL.at(0) * sndottol); 
				color.at(1) = color.at(1) + (mat.kd.at(1) * emL.at(1) * sndottol);
				color.at(2) = color.at(2) + (mat.kd.at(2) * emL.at(2) * sndottol);
				Matrix::printVector(color);
				std::vector<double> toC = rayL - ections;
				toC = toC % Matrix::vectorLength(toC);
				std::vector<double> spR = (2 * sndottol * snrm) - toL;
				/*if (X==29 && Y ==48) {
					
					Matrix::printVector(mat.ka);
					Matrix::printVector(mat.kd);
					Matrix::printVector(mat.ks);
					Matrix::printVector(toC);
					Matrix::printVector(toL);
					Matrix::printVector(spR);
					Matrix::printVector(ptL);
					Matrix::printVector(emL);
					Matrix::printVector(color);
					cout << (pow((toC & spR),16.0)) << endl;
					
				}	*/	
				
				color.at(0) += mat.ks.at(0) * emL.at(0) * pow((toC & spR),4.0); 
				color.at(1) += mat.ks.at(1) * emL.at(1) * pow((toC & spR),4.0); 
				color.at(2) += mat.ks.at(2) * emL.at(2) * pow((toC & spR),4.0); 
				/*if (X==29 && Y ==48) {
					Matrix::printVector(color);
				}	*/
				
				
				
			}
	}
		Red = (int)min(255.0, (color.at(0) * 254.999));
		Green = (int)min(255.0, (color.at(1) * 254.999));
		Blue = (int)min(255.0, (color.at(2) * 254.999));
}